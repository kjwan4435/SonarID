﻿using System;
using System.Numerics;
using Tizen;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

using System.Threading.Tasks;

namespace FingerID
{
    class Program : NUIApplication
    {
        Window window;
        Window TrialInitWindow;

        // INIT PAGE
        public TextField IpEntry;
        public TextField SubIdEntry;
        public Button InitButton;

        // BLOCK INIT PAGE
        public TextLabel BlockInitLabel;
        public Button BlockInitButton;

        // On TRIAL PAGE
        string ImageFilePath = "/opt/usr/apps/org.tizen.example.FingerID/shared/res/";
        public Button Stimuli;
        public Button Background;

        public Button TrialInitButton;      // TRIAL INIT PAGE
        public TextLabel TrialWaitLabel;    // TRIAL WAIT PAGE
        public TextLabel EndLabel;          // END PAGE

        // TRIAL
        Trials trials;
        int numPostures = 1;
        int numTargets = 1;                 // total number of targets
        int numFingers = 3;                 // number of fingers we will consider
        int numRepsBlock = 20;               // number of reps in each block
        int numBlocks = 4;                  // number of blocks in the study

        // SoundPlayer
        Complex[] seq;
        int dur;
        double[] wave;
        dataPlayer player;

        // TcpStreamer
        TcpStreamer tcpStreamer;

        int TIME_FIX = 500;  // fix time
        int TIME_TRIAL = 3000; // timeout time
        int TIME_PAUSE = 500;

        void Initialize()
        {
            window = InitPage();
            window.Show();
        }

        public Window InitPage()
        {
            Window InitWindow = new Window(new Rectangle(0, 0, 360, 360));

            IpEntry = new TextField
            {
                Text = "192.168.0.46",
                TextColor = Color.White,
                PlaceholderText = "Enter IP",
                PointSize = 8.0f,
                HorizontalAlignment = HorizontalAlignment.Center,
                PositionY = 80
            };

            SubIdEntry = new TextField
            {
                PlaceholderText = "Enter Sub ID",
                TextColor = Color.White,
                PlaceholderTextColor = Color.White,
                PointSize = 8.0f,
                HorizontalAlignment = HorizontalAlignment.Center,
                PositionY = 140
            };

            InitButton = new Button
            {
                Text = "START",
                PointSize = 8.0f,
                TextColor = Color.White,
                BackgroundColor = Color.Blue,
                Size = new Size(240, 60),
                Position = new Position(60, 200)
            };

            InitButton.StateChangedEvent += (s,e) => { InitButton.BackgroundColor = Color.Blue; };
            InitButton.ClickEvent += InitButtonClicked;

            InitWindow.KeyEvent += OnKeyEvent;
            InitWindow.Add(IpEntry);
            InitWindow.Add(SubIdEntry);
            InitWindow.Add(InitButton);
            return InitWindow;
        }

        public Window BlockInitPage()
        {
            Window BlockInitWindow = new Window(new Rectangle(0, 0, 360, 360));

            BlockInitLabel = new TextLabel
            {
                Text = "Block: " + (numBlocks - trials.numberBlocksLeft + 1),
                PointSize = 8.0f,
                TextColor = Color.White,
                HorizontalAlignment = HorizontalAlignment.Center,
                PositionY = 120
            };

            BlockInitButton = new Button
            {
                Text = "Start New Block",
                PointSize = 8.0f,
                TextColor = Color.White,
                BackgroundColor = Color.Blue,
                Size = new Size(240, 60),
                Position = new Position(60, 200)
            };
            BlockInitButton.StateChangedEvent += (s, e) => { BlockInitButton.BackgroundColor = Color.Blue; };
            BlockInitButton.ClickEvent += BlockInitButtonClicked;

            BlockInitWindow.KeyEvent += OnKeyEvent;
            BlockInitWindow.Add(BlockInitLabel);
            BlockInitWindow.Add(BlockInitButton);
            return BlockInitWindow;
        }

        public Window TrialInitPage()
        {
            TrialInitWindow = new Window(new Rectangle(0, 0, 360, 360));

            TrialInitButton = new Button
            {
                SizeWidth = 360,
                SizeHeight = 360,
                BackgroundColor = Color.Black,
                TextColor = Color.White,
                Text = "TAP TO START",
                PointSize = 8.0f,
                Position = new Position(0, 0),
                IsSelectable = false
            };

            TrialWaitLabel = new TextLabel
            {
                BackgroundColor = Color.Black,
                TextColor = Color.White,
                Text = "·",
                PointSize = 30.0f,
                HorizontalAlignment = HorizontalAlignment.Center,
                PositionY = 110
            };

            TrialInitButton.StateChangedEvent += (s, e) => { TrialInitButton.BackgroundColor = Color.Black; };
            TrialInitButton.ClickEvent += TrialInitButtonClicked;

            TrialInitWindow.KeyEvent += OnKeyEvent;
            TrialInitWindow.Add(TrialInitButton);
            return TrialInitWindow;
        }

        public Window OnTrialPage()
        {
            Window OnTrialWindow = new Window(new Rectangle(0, 0, 360, 360));
            int targetNum = trials.trials[0].targetNum;
            int finger = trials.trials[0].finger;
            Position target = getTargetPoint(targetNum);
            Global.logMessage("FINGER is " + finger);
            Stimuli = new Button
            {
                SizeWidth = 120,
                SizeHeight = 120,
                BackgroundColor = Color.White,
                Position = target,
                Text = "",
                BackgroundImage = ImageFilePath + "hand" + (finger+1) + ".png"
            };
            Stimuli.TouchEvent += OnStimuliTouchEvent;
            //Stimuli.ClickEvent += OnStimuliClickedEvent;
            
            Background = new Button
            {
                SizeWidth = 360,
                SizeHeight = 360,
                BackgroundColor = Color.Black,
                Position = new Position(0, 0, 0),
                Text = "",
            };
            Background.TouchEvent += OnBackgroundTouchEvent;
            //Background.ClickEvent += OnBackgroundClickedEvent;

            OnTrialWindow.KeyEvent += OnKeyEvent;
            OnTrialWindow.Add(Background);
            OnTrialWindow.Add(Stimuli);
            return OnTrialWindow;
        }

        public Window EndPage()
        {
            Window EndWindow = new Window(new Rectangle(0, 0, 360, 360));
            EndLabel = new TextLabel
            {
                Text = "END :)",
                PointSize = 8.0f,
                TextColor = Color.White,
                HorizontalAlignment = HorizontalAlignment.Center,
                PositionY = 160
            };
            EndWindow.KeyEvent += OnKeyEvent;
            EndWindow.Add(EndLabel);
            return EndWindow;
        }


        Position getTargetPoint(int targetNum)
        {
            float diagLength = 84;
            switch (targetNum)
            {
                case 0: return new Position(120, 120, 1);
                case 1: return new Position(120, 0, 1);
                case 2: return new Position(120 + diagLength, 120 - diagLength, 1);
                case 3: return new Position(240, 120, 1);
                case 4: return new Position(120 + diagLength, 120 + diagLength, 1);
                case 5: return new Position(120, 240, 1);
                case 6: return new Position(120 - diagLength, 120 + diagLength, 1);
                case 7: return new Position(0, 120, 1);
                case 8: return new Position(120 - diagLength, 120 - diagLength, 1);
            }
            return new Position(999, 999, 1);
        }


        public void InitButtonClicked(object sender, Button.ClickEventArgs e)
        {
            Global.IP_ADDRESS = IpEntry.Text;
            if (SubIdEntry.Text == "") Global.SubId = 0;
            else Global.SubId = Convert.ToInt32(SubIdEntry.Text);
            Global.logMessage("IP: " + Global.IP_ADDRESS + "/ Sub: " + Global.SubId);
            tcpStreamer = new TcpStreamer();
            tcpStreamer.sendInitMsg(Utilities.leftPad(Convert.ToString(Global.SubId), 4) + DateTime.UtcNow.Day + DateTime.UtcNow.Millisecond);
            trials.initTrialLog();
            window = BlockInitPage();
        }

        public void BlockInitButtonClicked(object sender, Button.ClickEventArgs e)
        {
            if (!trials.initTrials(numPostures, numTargets, numFingers, numRepsBlock))
            { Global.logMessage("No blocks in the study. Ending"); }
            Global.logMessage("Trials generated: " + Convert.ToString(trials.trials.Count));
            window = TrialInitPage();
        }

        async public void TrialInitButtonClicked(object sender, Button.ClickEventArgs e)
        {
            long validator = -1;
            
            try
            {
                TrialInitWindow.Remove(TrialInitButton);
                TrialInitWindow.Add(TrialWaitLabel);
                tcpStreamer.startStreaming();
                player.play();
                trials.trials[0].startTime = DateTime.UtcNow.Ticks;
                validator = trials.trials[0].startTime;
                await Task.Delay(500);
                window = OnTrialPage();
                await Task.Delay(3000);
            }
            catch (Exception error)
            {
                Global.logMessage(Convert.ToString(error));
            }

            if (trials.trials.Count != 0)
                if (trials.trials[0].touchDownTime == -1 && validator == trials.trials[0].startTime)
                {
                    Global.logMessage("TIMEOUT CALLED");
                    trialFinish();
                }
        }

        void OnStimuliClickedEvent()
        {
            trials.trials[0].touchDownTime = DateTime.UtcNow.Ticks;
            trials.trials[0].correctDown = true;
            trialFinish();
        }

        void OnBackgroundClickedEvent()
        {
            trials.trials[0].touchDownTime = DateTime.UtcNow.Ticks;
            trialFinish();
        }

        async void trialFinish()
        {
            window.Remove(Stimuli);
            await Task.Delay(500);
            player.stop();
            tcpStreamer.stop();
            trials.trials[0].endTime = DateTime.UtcNow.Ticks;

            tcpStreamer.transferData();
            Global.logMessage(trials.trials[0].correctDown + " | t: " + (trials.trials[0].touchDownTime - trials.trials[0].startTime) / 10000);
            tcpStreamer.sendBlockMsg(trials.trials[0]);
            TcpStreamer.indexer += 1;
            trials.trialsDone.Add(trials.trials[0]);
            trials.trials.RemoveAt(0);

            Global.logMessage("TrialsDone: " + trials.trialsDone.Count + ", Left: " + trials.trials.Count);

            if (trials.trials.Count == 0)
            {
                Global.logMessage("Block Left: " + trials.numberBlocksLeft);
                if (trials.numberBlocksLeft == 0)
                    window = EndPage();
                else
                    window = BlockInitPage();
            }
            else
                window = TrialInitPage();
        }

        private void OnKeyEvent(object sender, Window.KeyEventArgs e)
        {
            if (e.Key.State == Key.StateType.Down && (e.Key.KeyPressedName == "XF86Back" || e.Key.KeyPressedName == "Escape"))
            {
                Exit();
            }
        }

        public bool OnStimuliTouchEvent(object sender, View.TouchEventArgs e)
        {
            int x = (int)e.Touch.GetScreenPosition(0).X;
            int y = (int)e.Touch.GetScreenPosition(0).Y;
            long t = DateTime.UtcNow.Ticks;
            trials.trials[0].pts.Add(new PointTime(x, y, t));
            Global.logMessage("TOTAL PTS: " + trials.trials[0].pts.Count + "| " + x + ", " + y);

            if (e.Touch.GetState(0) == PointStateType.Down && trials.trials[0].pts.Count == 1)
            {
                Log.Info("LOG_TAG", "DOWN: " + e.Touch.GetScreenPosition(0).X + ", " + Convert.ToString(e.Touch.GetScreenPosition(0).Y));
                OnStimuliClickedEvent();
            }
            else if (e.Touch.GetState(0) == PointStateType.Up)
            {
                Log.Info("LOG_TAG", "UP: " + e.Touch.GetScreenPosition(0).X + ", " + Convert.ToString(e.Touch.GetScreenPosition(0).Y));
            }
            return true;
        }

        public bool OnBackgroundTouchEvent(object sender, View.TouchEventArgs e)
        {
            int x = (int)e.Touch.GetScreenPosition(0).X;
            int y = (int)e.Touch.GetScreenPosition(0).Y;
            long t = DateTime.UtcNow.Ticks;
            trials.trials[0].pts.Add(new PointTime(x, y, t));
            Global.logMessage("TOTAL PTS: " + trials.trials[0].pts.Count + "| " + x + ", " + y);

            if (e.Touch.GetState(0) == PointStateType.Down && trials.trials[0].pts.Count == 1)
            {
                Log.Info("LOG_TAG", "DOWN: " + e.Touch.GetScreenPosition(0).X + ", " + Convert.ToString(e.Touch.GetScreenPosition(0).Y));
                OnBackgroundClickedEvent();
            }
            else if (e.Touch.GetState(0) == PointStateType.Up)
            {
                Log.Info("LOG_TAG", "UP: " + e.Touch.GetScreenPosition(0).X + ", " + Convert.ToString(e.Touch.GetScreenPosition(0).Y));
            }
            return true;
        }

        static void Main(string[] args)
        {
            var app = new Program();
            app.Run(args);
        }

        protected override void OnCreate()
        {
            base.OnCreate();
            seq = soundGenerator.generateZCSeq(63, 127, 1024);
            dur = (int)Math.Ceiling((float)(TIME_FIX + TIME_TRIAL + TIME_PAUSE) / 21.33);
            wave = soundGenerator.generateCarrier(48000, 20250, dur, 5000, seq);
            player = new dataPlayer(wave);
            Global.logMessage("Player prepared");
            trials = new Trials();
            trials.numberBlocksLeft = numBlocks;
            Initialize();
        }
        protected override void OnResume()
        {
            base.OnResume();
            Global.logMessage("OnResume called");
        }
        protected override void OnPause()
        {
            base.OnPause();
            Global.logMessage("OnPause called");
        }
        protected override void OnTerminate()
        {
            base.OnTerminate();
            Global.logMessage("OnTerminate called");
        }
    }

    
}
